package burp;

import javax.swing.AbstractAction;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Menu to configure the extension options.
 */
class TopMenu implements Runnable, IExtensionStateListener {

    static volatile boolean ENCRYPT_RESPONSE_FOR_PROXY = Boolean.TRUE;
    private static final String ENCRYPT_RESPONSE_FOR_PROXY_CFG_KEY = "ENCRYPT_RESPONSE_FOR_PROXY";
    static volatile boolean ENCRYPTION_PHASE_REQUEST = Boolean.TRUE;
    private static final String ENCRYPTION_PHASE_REQUEST_CFG_KEY = "ENCRYPTION_PHASE_REQUEST";
    static volatile boolean DECRYPTION_PHASE_RESPONSE = Boolean.TRUE;
    private static final String DECRYPTION_PHASE_RESPONSE_CFG_KEY = "DECRYPTION_PHASE_RESPONSE";
    static volatile boolean CHECKSUM_PHASE_REQUEST = Boolean.TRUE;
    private static final String CHECKSUM_PHASE_REQUEST_CFG_KEY = "CHECKSUM_PHASE_REQUEST";


    private JMenu cfgMenu;

    /**
     * Ref on Burp tool to manipulate the HTTP requests and have access to API to identify the source of the activity (tool name).
     */
    private IBurpExtenderCallbacks callbacks;


    TopMenu(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
        //Load the save state of the options
        String value = this.callbacks.loadExtensionSetting(ENCRYPT_RESPONSE_FOR_PROXY_CFG_KEY);
        ENCRYPT_RESPONSE_FOR_PROXY = Boolean.parseBoolean(value);
    }

    /**
     * Build the options menu used to configure the extension.
     */
    @Override
    public void run() {
        //Build the menu
        this.cfgMenu = new JMenu("e2ee demo");
        //Add the sub menu to restrict the logging of requests in defined target scope
        String menuText = "Encrypt resposne for proxy";
        final JCheckBoxMenuItem encrypt_response_proxy = new JCheckBoxMenuItem(menuText, ENCRYPT_RESPONSE_FOR_PROXY);
        encrypt_response_proxy.addActionListener(new AbstractAction(menuText) {
            public void actionPerformed(ActionEvent e) {
                if (encrypt_response_proxy.isSelected()) {
                    TopMenu.this.callbacks.saveExtensionSetting(ENCRYPT_RESPONSE_FOR_PROXY_CFG_KEY, Boolean.TRUE.toString());
                    TopMenu.ENCRYPT_RESPONSE_FOR_PROXY = Boolean.TRUE;
                } else {
                    TopMenu.this.callbacks.saveExtensionSetting(ENCRYPT_RESPONSE_FOR_PROXY_CFG_KEY, Boolean.FALSE.toString());
                    TopMenu.ENCRYPT_RESPONSE_FOR_PROXY = Boolean.FALSE;
                }
            }
        });
        this.cfgMenu.add(encrypt_response_proxy);

        menuText = "Encryption Phase for Request";
        final JCheckBoxMenuItem encryption_phase_request = new JCheckBoxMenuItem(menuText, ENCRYPTION_PHASE_REQUEST);
        encryption_phase_request.addActionListener(new AbstractAction(menuText) {
            public void actionPerformed(ActionEvent e) {
                if (encryption_phase_request.isSelected()) {
                    TopMenu.this.callbacks.saveExtensionSetting(ENCRYPTION_PHASE_REQUEST_CFG_KEY, Boolean.TRUE.toString());
                    TopMenu.ENCRYPTION_PHASE_REQUEST = Boolean.TRUE;
                } else {
                    TopMenu.this.callbacks.saveExtensionSetting(ENCRYPTION_PHASE_REQUEST_CFG_KEY, Boolean.FALSE.toString());
                    TopMenu.ENCRYPTION_PHASE_REQUEST = Boolean.FALSE;
                }
            }
        });
        this.cfgMenu.add(encryption_phase_request);

        menuText = "Decryption Phase for Response";
        final JCheckBoxMenuItem decryption_phase_response = new JCheckBoxMenuItem(menuText, DECRYPTION_PHASE_RESPONSE);
        decryption_phase_response.addActionListener(new AbstractAction(menuText) {
            public void actionPerformed(ActionEvent e) {
                if (decryption_phase_response.isSelected()) {
                    TopMenu.this.callbacks.saveExtensionSetting(DECRYPTION_PHASE_RESPONSE_CFG_KEY, Boolean.TRUE.toString());
                    TopMenu.DECRYPTION_PHASE_RESPONSE = Boolean.TRUE;
                } else {
                    TopMenu.this.callbacks.saveExtensionSetting(DECRYPTION_PHASE_RESPONSE_CFG_KEY, Boolean.FALSE.toString());
                    TopMenu.DECRYPTION_PHASE_RESPONSE = Boolean.FALSE;
                }
            }
        });
        this.cfgMenu.add(decryption_phase_response);

        menuText = "Checksum Phase for Request";
        final JCheckBoxMenuItem checksum_phase_request = new JCheckBoxMenuItem(menuText, CHECKSUM_PHASE_REQUEST);
        checksum_phase_request.addActionListener(new AbstractAction(menuText) {
            public void actionPerformed(ActionEvent e) {
                if (checksum_phase_request.isSelected()) {
                    TopMenu.this.callbacks.saveExtensionSetting(CHECKSUM_PHASE_REQUEST_CFG_KEY, Boolean.TRUE.toString());
                    TopMenu.CHECKSUM_PHASE_REQUEST = Boolean.TRUE;
                } else {
                    TopMenu.this.callbacks.saveExtensionSetting(CHECKSUM_PHASE_REQUEST_CFG_KEY, Boolean.FALSE.toString());
                    TopMenu.CHECKSUM_PHASE_REQUEST = Boolean.FALSE;
                }
            }
        });
        this.cfgMenu.add(checksum_phase_request);


        //Add it to BURP menu
        JFrame burpFrame = TopMenu.getBurpFrame();
        if (burpFrame != null) {
            JMenuBar jMenuBar = burpFrame.getJMenuBar();
            jMenuBar.add(this.cfgMenu);
            jMenuBar.repaint();
        }
    }

    /**
     * Remove the menu from BURP menu bar.
     *
     * @see "https://github.com/PortSwigger/param-miner/blob/master/src/burp/Utilities.java"
     */
    @Override
    public void extensionUnloaded() {
        JFrame burpFrame = TopMenu.getBurpFrame();
        if (burpFrame != null && this.cfgMenu != null) {
            JMenuBar jMenuBar = burpFrame.getJMenuBar();
            jMenuBar.remove(this.cfgMenu);
            jMenuBar.repaint();
        }
    }

    /**
     * Get a reference on the BURP main frame.
     *
     * @return BURP main frame.
     * @see "https://github.com/PortSwigger/param-miner/blob/master/src/burp/Utilities.java"
     */
    static JFrame getBurpFrame() {
        for (Frame f : Frame.getFrames()) {
            if (f.isVisible() && f.getTitle().startsWith(("Burp Suite"))) {
                return (JFrame) f;
            }
        }
        return null;
    }

}
