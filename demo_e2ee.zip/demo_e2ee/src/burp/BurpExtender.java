package burp;
/*
 * This plugin require JDK 9 nue to nashorn engine being used
 * */
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

import com.caoccao.javet.enums.JSRuntimeType;
import com.caoccao.javet.exceptions.JavetException;
import com.caoccao.javet.interop.V8Host;
import com.caoccao.javet.interop.V8Runtime;
import com.caoccao.javet.interop.loader.IJavetLibLoadingListener;
import com.caoccao.javet.interop.loader.JavetLibLoader;

import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Date;
import javax.swing.*;

public class BurpExtender implements IBurpExtender, IHttpListener
{
    private static final SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private PrintWriter stdout;
    Path javet_TempDirectory = Files.createTempDirectory("javet");
    public static final String ENCRYPTED_PARA = "ip";
    public static final String CHECKSUM_PARA = "checksum";
    public static final String DEECRYPTED_PARA = "result";
    public static final String SECRET = "373ebcba965940a92838c0646ceba5c38cbb408095213f1404b7566b15eb51c9";
    public static final int TOOL_PROXY = 4;
    public static final Boolean IS_ENCRYPTOR_MODE = true;
    TopMenu top_menu = null;
    public BurpExtender() throws IOException {
    }

    //
    // implement IBurpExtender
    //

    @Override
    public void registerExtenderCallbacks(final IBurpExtenderCallbacks callbacks)
    {
        // set our extension name
        this.callbacks = callbacks;
        helpers = callbacks.getHelpers();
        stdout = new PrintWriter(callbacks.getStdout(), true);
        JFrame burpFrame = TopMenu.getBurpFrame();
        top_menu = new TopMenu(callbacks);
        SwingUtilities.invokeLater(top_menu);
        callbacks.setExtensionName("demo e2ee");
        callbacks.registerHttpListener(this);
        callbacks.registerExtensionStateListener(top_menu);
        //callbacks.registerProxyListener(this);
        stdout.println("11111111111111111111111");
        stdout.println("Current JVM version - " + System.getProperty("java.version"));


        JavetLibLoader.setLibLoadingListener(new IJavetLibLoadingListener() {
            @Override
            public File getLibPath(JSRuntimeType jsRuntimeType) {
                return javet_TempDirectory.toFile();
            }
        });
    }
    @Override
    public void processHttpMessage(int toolFlag, boolean messageIsRequest, IHttpRequestResponse request) {

        String url_path = helpers.analyzeRequest(request).getUrl().getPath();
        int last_forward_slash = url_path.lastIndexOf('/');
        String last_url_path = url_path.substring(last_forward_slash + 1);
        String test = "";
        if (messageIsRequest) {
            byte request_bytes[] = request.getRequest();;
            IRequestInfo request_info = helpers.analyzeRequest(request_bytes);
            String i_request = helpers.bytesToString(request.getRequest());
            List<IParameter> parameters_list = request_info.getParameters();
            Map<String,IParameter> parameters_map = new HashMap<String,IParameter>();
            for (IParameter i : parameters_list) parameters_map.put(i.getName(),i);

            Boolean is_body_modified = false;

            if (last_url_path.equals("output") && top_menu.CHECKSUM_PHASE_REQUEST) {
                is_body_modified = true;
                String encryptedInput_para_value = helpers.urlDecode(parameters_map.get(ENCRYPTED_PARA).getValue());
                String checksum_para_value = helpers.urlDecode(parameters_map.get(CHECKSUM_PARA).getValue());
                try {
                    checksum_para_value = helpers.urlEncode(initiate_checksum(encryptedInput_para_value));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                request_bytes = update_parameter(request_bytes, parameters_map.get(CHECKSUM_PARA), CHECKSUM_PARA, checksum_para_value, parameters_map.get(CHECKSUM_PARA).getType());
            }
            if (last_url_path.equals("output") && top_menu.ENCRYPTION_PHASE_REQUEST) {
                is_body_modified = true;
                String encryptedInput_para_value = helpers.urlDecode(parameters_map.get(ENCRYPTED_PARA).getValue());
                try {
                    encryptedInput_para_value = helpers.urlEncode(initiate_encryption(encryptedInput_para_value));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                request_bytes = update_parameter(request_bytes, parameters_map.get(ENCRYPTED_PARA), ENCRYPTED_PARA, encryptedInput_para_value, parameters_map.get(ENCRYPTED_PARA).getType());
            }
            if (is_body_modified) {
                request.setRequest(request_bytes);
                stdout.println(helpers.bytesToString(request_bytes));
            }


            stdout.println("========== START REQUEST=============");
            stdout.println(sdf1.format(new Timestamp((new Date()).getTime())));
            stdout.println(i_request);
            stdout.println("========== END RESPONSE=============");
        }else{
            byte response_bytes[] = request.getResponse();
            IRequestInfo response_info = helpers.analyzeRequest(response_bytes);
            List<String> header_list = response_info.getHeaders();
            byte[] body_res  = Arrays.copyOfRange(response_bytes, response_info.getBodyOffset(), response_bytes.length);
            String i_response = helpers.bytesToString(body_res);
            if(last_url_path.equals("e2ee.js")){
                i_response = override_response_stop_encryption_and_hardcode(i_response);
                request.setResponse(helpers.buildHttpMessage(header_list, i_response.getBytes()));
            }

            // decrypt for all tools except proxy if DECRYPTION_PHASE == True
            // decrypt proxy if DECRYPTION_PHASE == True and ENCRYPT_RESPONSE_FOR_PROXY == False
            if ( (last_url_path.equals("output") && callbacks.TOOL_PROXY != toolFlag && top_menu.DECRYPTION_PHASE_RESPONSE) || (last_url_path.equals("output") && callbacks.TOOL_PROXY == toolFlag && !top_menu.ENCRYPT_RESPONSE_FOR_PROXY && top_menu.DECRYPTION_PHASE_RESPONSE) ) {
                try {
                    if(i_response.contains("result")){
                        i_response = initiate_decryption(i_response, DEECRYPTED_PARA);
                        request.setResponse(helpers.buildHttpMessage(header_list, i_response.getBytes()));
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }else{
                System.out.println("UNIDENFIED SCENARIO");
            }
            /*
            if (last_url_path.equals("output") && callbacks.TOOL_PROXY == toolFlag && !top_menu.ENCRYPT_RESPONSE_FOR_PROXY && top_menu.DECRYPTION_PHASE) {
                try {
                    i_response = initiate_decryption(i_response, DEECRYPTED_PARA);
                    request.setResponse(helpers.buildHttpMessage(header_list, i_response.getBytes()));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }*/

            stdout.println("========== START REQUEST=============");
            stdout.println(sdf1.format(new Timestamp((new Date()).getTime())));
            stdout.println(helpers.bytesToString(request.getResponse()));
            stdout.println("========== END RESPONSE=============");

        }
    }

    private String retrieve_regex_match(String regex, String i_response){
        Matcher matcher = Pattern.compile(regex).matcher(i_response);
        Boolean is_found = matcher.find();
        if(is_found){
            return matcher.group(1);
        }
        return "";
    }

    private byte[] update_parameter(byte[] request_bytes, IParameter i_para, String para_name, String para_value, byte para_type) {
        String test;
        request_bytes = helpers.removeParameter(request_bytes, i_para);
        IParameter new_parameter = helpers.buildParameter(para_name, para_value, para_type);
        request_bytes = helpers.addParameter(request_bytes, new_parameter);
        test = helpers.bytesToString(request_bytes);
        return request_bytes;
    }

    private String call_javet(String statement, String filename) throws IOException {
        StringBuilder sb = new StringBuilder();
        String result = "";
        try (InputStream inputStream = getClass().getResourceAsStream(filename);
             Reader reader = new InputStreamReader(inputStream);
             BufferedReader bufferedReader = new BufferedReader(reader)) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            sb.append(statement).append("\n");
            try (V8Runtime v8Runtime = V8Host.getNodeInstance().createV8Runtime()) {
                result =  (v8Runtime.getExecutor(sb.toString()).execute().toString());
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return result;
    }
    public String override_response_stop_encryption_and_hardcode(String response){
        String search_1 = "const encryptedIP = CryptoJS.AES.encrypt(ip, localStorage.getItem(\"secret\")).toString();";
        String replace_1 = "const encryptedIP = ip;";
        String search_2 = "const secretKey1 = CryptoJS.lib.WordArray.random(32).toString();";
        String replace_2 = "const secretKey1 = \"" + SECRET + "\";";
        if(response.contains(search_1)){
            response = response.replace(search_1, replace_1);
        }
        if(response.contains(search_2)){
            response = response.replace(search_2, replace_2);
        }

        return response;
    }


    private String initiate_encryption(String input) throws IOException {
        String statement = "\n" + "var secret=\"" + SECRET + "\";var a = CryptoJS.AES.encrypt(\"" + input + "\", secret).toString();a;";
        //System.out.println("First JS First statement \n");
        //System.out.println(statement);
        //String result = URLEncoder.encode(call_js_func(statement, "C:\\Users\\GaryWong\\Desktop\\gw\\pentest_log\\dbs\\2023\\pentest_1365\\jsencrypt.js"), "UTF-8");
        String result = call_javet(statement, "/crypto-js.js");
        return result;
    }
    private String initiate_checksum(String input) throws IOException {
        String statement = "\n var a = CryptoJS.SHA256(\"" + input + "\").toString();a;";
        //System.out.println("First JS First statement \n");
        //System.out.println(statement);
        //String result = URLEncoder.encode(call_js_func(statement, "C:\\Users\\GaryWong\\Desktop\\gw\\pentest_log\\dbs\\2023\\pentest_1365\\jsencrypt.js"), "UTF-8");
        String result = call_javet(statement, "/crypto-js.js");
        return result;
    }

    private String initiate_decryption(String input, String key_name) throws IOException {
        String statement = "\n" + "var body_json =JSON.parse('" + input +"');var secret=\"" + SECRET + "\";var a = CryptoJS.AES.decrypt(body_json['" + key_name + "'], secret).toString();var b = Buffer.from(a, 'hex').toString();body_json['"+ key_name +"'] = b;var c = JSON.stringify(body_json);c;";
        //System.out.println("First JS First statement \n");
        //System.out.println(statement);
        //String result = URLEncoder.encode(call_js_func(statement, "C:\\Users\\GaryWong\\Desktop\\gw\\pentest_log\\dbs\\2023\\pentest_1365\\jsencrypt.js"), "UTF-8");
        String result = call_javet(statement, "/crypto-js.js");
        return result;
    }





}