/* 
 * @description DSSSApplet JavaScript End-to-End Encryption Package
 * @version 1.5.3 (09 April 2013) 
 * @author DS3, http://www.ds3global.com
 */
function DSSSCryptography() {}
var Modulus, Exponent;

function translateVerifyRSABlock(d, l, n) {
    var o = d + l;
    var e = Math.ceil(o.length / (n.length / 2));
    var h = "";
    for (var g = 0; g < e; g++) {
        h = h + n
    }
    var b = new BigInteger(getByteArray(o));
    h = h.substring(0, o.length * 2);
    var f = new BigInteger(h, 16);
    b = b.xor(f);
    var k = o.length.toString(16);
    if (o.length <= 15) {
        k = "0" + k
    }
    var m = "0B" + k + b.toString(16);
    var c = new BigInteger(m, 16);
    var j = new RSAKey();
    j.setPublic(Modulus, Exponent);
    var a = j.encrypt(c);
    return a.toString(16)
}

function translateChangePwdRSABlock(d, n, l, o) {
    var p = d + l;
    var e = Math.ceil(p.length / (o.length / 2));
    var h = "";
    for (var g = 0; g < e; g++) {
        h = h + o
    }
    var b = new BigInteger(getByteArray(p));
    h = h.substring(0, p.length * 2);
    var f = new BigInteger(h, 16);
    b = b.xor(f);
    var k = p.length.toString(16);
    if (p.length <= 15) {
        k = "0" + k
    }
    var m = "0B" + k + b.toString(16);
    var p = d + n;
    var e = Math.ceil(p.length / (o.length / 2));
    var h = "";
    for (var g = 0; g < e; g++) {
        h = h + o
    }
    b = new BigInteger(getByteArray(p));
    h = h.substring(0, p.length * 2);
    f = new BigInteger(h, 16);
    b = b.xor(f);
    k = p.length.toString(16);
    if (p.length <= 15) {
        k = "0" + k
    }
    block2 = "0C" + k + b.toString(16);
    var c = new BigInteger(m + block2, 16);
    var j = new RSAKey();
    j.setPublic(Modulus, Exponent);
    var a = j.encrypt(c);
    return a.toString(16)
}

function encryptSetPwdNoVerifyRSABlock(c, g, i) {
    var j = c + g;
    var f = new BigInteger(MD5(j), 16);
    var d = new BigInteger(i, 16);
    f = f.xor(d);
    var h = "0210" + f.toString(16);
    var b = new BigInteger(h, 16);
    var e = new RSAKey();
    e.setPublic(Modulus, Exponent);
    var a = e.encrypt(b);
    return a
}

function encryptSetPwdRSABlock(c, k, d, m) {
    var n = c + k;
    var h = new BigInteger(MD5(n), 16);
    var f = new BigInteger(m, 16);
    h = h.xor(f);
    var l = "0210" + h.toString(16);
    var e = d.length.toString(16);
    if (d.length < 16) {
        e = "0" + e
    }
    var i = new BigInteger(getByteArray(d));
    var j = "03" + e + i.toString(16);
    var b = new BigInteger(l + j, 16);
    var g = new RSAKey();
    g.setPublic(Modulus, Exponent);
    var a = g.encrypt(b);
    return a
}

function encryptChangePwdRSABlock(d, c, j, f, g, e) {
    var q = d + c;
    var l = new BigInteger(MD5(q), 16);
    var i = new BigInteger(g, 16);
    l = l.xor(i);
    var p = "0110" + l.toString(16);
    var q = d + j;
    var l = new BigInteger(MD5(q), 16);
    var i = new BigInteger(e, 16);
    l = l.xor(i);
    var o = "0210" + l.toString(16);
    var h = f.length.toString(16);
    if (f.length < 16) {
        h = "0" + h
    }
    var m = new BigInteger(getByteArray(f));
    var n = "03" + h + m.toString(16);
    var b = new BigInteger(p + o + n, 16);
    var k = new RSAKey();
    k.setPublic(Modulus, Exponent);
    var a = k.encrypt(b);
    return a
}

function encryptChangePwdNoVerifyRSABlock(d, c, g, f, e) {
    var m = d + c;
    var j = new BigInteger(MD5(m), 16);
    var h = new BigInteger(f, 16);
    j = j.xor(h);
    var l = "0110" + j.toString(16);
    var m = d + g;
    var j = new BigInteger(MD5(m), 16);
    var h = new BigInteger(e, 16);
    j = j.xor(h);
    var k = "0210" + j.toString(16);
    var b = new BigInteger(l + k, 16);
    var i = new RSAKey();
    i.setPublic(Modulus, Exponent);
    var a = i.encrypt(b);
    return a
}

function encryptVerifyRSABlock(d, k, e, l) {
    var m = d + k;
    var i = new BigInteger(MD5(m), 16);
    var f = new BigInteger(l, 16);
    i = i.xor(f);
    var g = e.length.toString(16);
    if (e.length < 16) {
        g = "0" + g
    }
    var j = new BigInteger(getByteArray(e));
    var b = "03" + g + j.toString(16);
    biTLVOTIP = new BigInteger(b, 16);
    f = i.toString(16) + biTLVOTIP.toString(16);
    var c = new BigInteger("0110" + f, 16);
    var h = new RSAKey();
    h.setPublic(Modulus, Exponent);
    var a = h.encrypt(c);
    return a
}

function getUserIDHexString(a) {
    var d = getByteArray(a);
    userIDHexString = "";
    for (var c = 0; c < d.length; c++) {
        var b = "";
        if (d[c] <= 15) {
            b = "0" + d[c].toString(16)
        } else {
            b = d[c].toString(16)
        }
        userIDHexString = userIDHexString + b
    }
    return userIDHexString + "00"
}

function encryptVerify2RSABlock(d, f, l) {
    var e = l.substring(0, f.length * 2);
    var k = new BigInteger(e, 16);
    var h = f.length.toString(16);
    if (f.length < 16) {
        h = "0" + h
    }
    var j = new BigInteger(getByteArray(f));
    var b = "03" + h + (j.xor(k)).toString(16);
    biTLVOTIP = new BigInteger(b, 16);
    var n = d + f;
    var m = new BigInteger(MD5(n), 16);
    var g = new BigInteger(l, 16);
    m = m.xor(g);
    g = biTLVOTIP.toString(16) + "0210" + m.toString(16);
    var c = new BigInteger(g, 16);
    var i = new RSAKey();
    i.setPublic(Modulus, Exponent);
    var a = i.encrypt(c);
    return a
}

function encryptVerifyOtipRSABlock(b) {
    var a = b.length.toString(16);
    if (b.length < 16) {
        a = "0" + a
    }
    var c = new BigInteger(getByteArray(b));
    var d = "03" + a + c.toString(16);
    biTLVOTIP = new BigInteger(d, 16);
    var e = new RSAKey();
    e.setPublic(Modulus, Exponent);
    var f = e.encrypt(biTLVOTIP);
    return f
}

function encryptVerifyStaticRSABlock(c, h, i) {
    var j = c + h;
    var g = MD5(j);
    var f = new BigInteger(g, 16);
    var d = new BigInteger(i, 16);
    f = f.xor(d);
    var b = new BigInteger("0110" + f.toString(16), 16);
    var e = new RSAKey();
    e.setPublic(Modulus, Exponent);
    var a = e.encrypt(b);
    return a
}

function encryptVascoResponse(f, i) {
    var g = i;
    if (i.length != 16) {
        g = MD5(i)
    }
    g = g.substring(0, f.length * 2);
    var h = new BigInteger(getByteArray(f));
    var c = new BigInteger(g, 16);
    h = h.xor(c);
    var d = f.length.toString(16);
    if (f.length < 16) {
        d = "0" + d
    }
    var b = new BigInteger("03" + d + h.toString(16), 16);
    var e = new RSAKey();
    e.setPublic(Modulus, Exponent);
    var a = e.encrypt(b);
    return a
}

function encryptVerifyISOBlock(e) {
    function d(n, k) {
        var q = new Array();
        var o, p, g;
        for (o = 0; o < k; o++) {
            q[o] = 255
        }
        for (o = 0; o < n.length && o < 9; o++) {
            var r = n.charCodeAt(o);
            p = r % 16;
            if (o % 2 == 0) {
                q[o / 2] = (q[o / 2] & (p * 16 + 15))
            } else {
                var m = Math.floor(o / 2);
                q[m] = (q[m] & (p | 240))
            }
        }
        return q
    }

    function a(g) {
        var h = "0608";
        if (g.length <= 9) {
            h += "0" + g.length
        } else {
            h += g.length
        }
        h += Util.toHexString(d(g, 7));
        return h
    }
    var b = new BigInteger(a(e), 16);
    var c = new RSAKey();
    c.setPublic(Modulus, Exponent);
    var f = c.encrypt(b).toString(16);
    return f
}

function Util() {}
Util.toHexString = function(d) {
    var c = "";
    for (var a = 0; a < d.length; a++) {
        var b;
        if (typeof d[a] == "number") {
            b = (d[a]).toString(16)
        } else {
            if (typeof d[a] == "string") {
                b = d.charCodeAt(a).toString(16)
            }
        }
        if (b.length == 1) {
            b = "0" + b
        }
        c += b
    }
    return c
};

function support32bitComputation() {
    var e = 305419896;
    var d = 2882400152;
    var f = e + d;
    if (f == 3187820048) {
        return true
    } else {
        return false
    }
};
/*
 * @fileOverview Javascript Big Integer implementation(jsbn.js)
 * @version 1.0
 */
/*
 * This package includes code written by Tom Wu.
 * 
 * Copyright (c) 2003-2005  Tom Wu
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 */
function getByteArray(c) {
    a = new Array();
    for (var b = 0; b < c.length; b++) {
        a[b] = c.charCodeAt(b)
    }
    return a
}
var dbits;
var j_lm = (((244837814094590) & 16777215) == 15715070);

function BigInteger(e, d, f) {
    if (e != null) {
        if ("number" == typeof e) {
            this.fromNumber(e, d, f)
        } else {
            if (d == null && "string" != typeof e) {
                this.fromString(e, 256)
            } else {
                this.fromString(e, d)
            }
        }
    }
}

function nbi() {
    return new BigInteger(null)
}

function am1(g, b, d, f, k, h) {
    while (--h >= 0) {
        var e = b * this[g++] + d[f] + k;
        k = Math.floor(e / 67108864);
        d[f++] = e & 67108863
    }
    return k
}

function am2(g, r, s, f, p, b) {
    var o = r & 32767,
        q = r >> 15;
    while (--b >= 0) {
        var e = this[g] & 32767;
        var k = this[g++] >> 15;
        var d = q * e + k * o;
        e = o * e + ((d & 32767) << 15) + s[f] + (p & 1073741823);
        p = (e >>> 30) + (d >>> 15) + q * k + (p >>> 30);
        s[f++] = e & 1073741823
    }
    return p
}

function am3(g, r, s, f, p, b) {
    var o = r & 16383,
        q = r >> 14;
    while (--b >= 0) {
        var e = this[g] & 16383;
        var k = this[g++] >> 14;
        var d = q * e + k * o;
        e = o * e + ((d & 16383) << 14) + s[f] + p;
        p = (e >> 28) + (d >> 14) + q * k;
        s[f++] = e & 268435455
    }
    return p
}
/*
if (navigator.appName == "Nokia") {
    BigInteger.prototype.am = am3;
    dbits = 28
} else {
    if (j_lm && (navigator.appName == "Microsoft Internet Explorer")) {
        BigInteger.prototype.am = am2;
        dbits = 30
    } else {
        if (j_lm && (navigator.appName != "Netscape")) {
            BigInteger.prototype.am = am1;
            dbits = 26
        } else {
            if ((4294967295 == -1) && (navigator.appName == "Netscape")) {
                BigInteger.prototype.am = am1;
                dbits = 26
            } else {
                BigInteger.prototype.am = am3;
                dbits = 28
            }
        }
    }
}
*/
BigInteger.prototype.am = am3;
                dbits = 28
BigInteger.prototype.DB = dbits;
BigInteger.prototype.DM = ((1 << dbits) - 1);
BigInteger.prototype.DV = (1 << dbits);
var BI_FP = 52;
BigInteger.prototype.FV = Math.pow(2, BI_FP);
BigInteger.prototype.F1 = BI_FP - dbits;
BigInteger.prototype.F2 = 2 * dbits - BI_FP;
var BI_RM = "0123456789abcdefghijklmnopqrstuvwxyz";
var BI_RC = new Array();
var rr, vv;
rr = "0".charCodeAt(0);
for (vv = 0; vv <= 9;
    ++vv) {
    BI_RC[rr++] = vv
}
rr = "a".charCodeAt(0);
for (vv = 10; vv < 36;
    ++vv) {
    BI_RC[rr++] = vv
}
rr = "A".charCodeAt(0);
for (vv = 10; vv < 36;
    ++vv) {
    BI_RC[rr++] = vv
}

function int2char(b) {
    return BI_RM.charAt(b)
}

function intAt(d, b) {
    var e = BI_RC[d.charCodeAt(b)];
    return (e == null) ? -1 : e
}

function bnpCopyTo(c) {
    for (var b = this.t - 1; b >= 0;
        --b) {
        c[b] = this[b]
    }
    c.t = this.t;
    c.s = this.s
}

function bnpFromInt(b) {
    this.t = 1;
    this.s = (b < 0) ? -1 : 0;
    if (b > 0) {
        this[0] = b
    } else {
        if (b < -1) {
            this[0] = b + DV
        } else {
            this.t = 0
        }
    }
}

function nbv(b) {
    var c = nbi();
    c.fromInt(b);
    return c
}

function bnpFromString(j, d) {
    var f;
    if (d == 16) {
        f = 4
    } else {
        if (d == 8) {
            f = 3
        } else {
            if (d == 256) {
                f = 8
            } else {
                if (d == 2) {
                    f = 1
                } else {
                    if (d == 32) {
                        f = 5
                    } else {
                        if (d == 4) {
                            f = 2
                        } else {
                            this.fromRadix(j, d);
                            return
                        }
                    }
                }
            }
        }
    }
    this.t = 0;
    this.s = 0;
    var h = j.length,
        e = false,
        g = 0;
    while (--h >= 0) {
        var c = (f == 8) ? j[h] & 255 : intAt(j, h);
        if (c < 0) {
            if (j.charAt(h) == "-") {
                e = true
            }
            continue
        }
        e = false;
        if (g == 0) {
            this[this.t++] = c
        } else {
            if (g + f > this.DB) {
                this[this.t - 1] |= (c & ((1 << (this.DB - g)) - 1)) << g;
                this[this.t++] = (c >> (this.DB - g))
            } else {
                this[this.t - 1] |= c << g
            }
        }
        g += f;
        if (g >= this.DB) {
            g -= this.DB
        }
    }
    if (f == 8 && (j[0] & 128) != 0) {
        this.s = -1;
        if (g > 0) {
            this[this.t - 1] |= ((1 << (this.DB - g)) - 1) << g
        }
    }
    this.clamp();
    if (e) {
        BigInteger.ZERO.subTo(this, this)
    }
}

function bnpClamp() {
    var b = this.s & this.DM;
    while (this.t > 0 && this[this.t - 1] == b) {
        --this.t
    }
}

function bnToString(e) {
    if (this.s < 0) {
        return "-" + this.negate().toString(e)
    }
    var f;
    if (e == 16) {
        f = 4
    } else {
        if (e == 8) {
            f = 3
        } else {
            if (e == 2) {
                f = 1
            } else {
                if (e == 32) {
                    f = 5
                } else {
                    if (e == 4) {
                        f = 2
                    } else {
                        return this.toRadix(e)
                    }
                }
            }
        }
    }
    var h = (1 << f) - 1,
        n, c = false,
        j = "",
        g = this.t;
    var l = this.DB - (g * this.DB) % f;
    if (g-- > 0) {
        if (l < this.DB && (n = this[g] >> l) > 0) {
            c = true;
            j = int2char(n)
        }
        while (g >= 0) {
            if (l < f) {
                n = (this[g] & ((1 << l) - 1)) << (f - l);
                n |= this[--g] >> (l += this.DB - f)
            } else {
                n = (this[g] >> (l -= f)) & h;
                if (l <= 0) {
                    l += this.DB;
                    --g
                }
            }
            if (n > 0) {
                c = true
            }
            if (c) {
                j += int2char(n)
            }
        }
    }
    if (e == 16 && j.length % 2 > 0) {
        j = "0" + j
    }
    if (e == 16 && !c && j.length == 0) {
        return ""
    }
    return c ? j : "0"
}

function bnNegate() {
    var b = nbi();
    BigInteger.ZERO.subTo(this, b);
    return b
}

function bnAbs() {
    return (this.s < 0) ? this.negate() : this
}

function bnCompareTo(b) {
    var d = this.s - b.s;
    if (d != 0) {
        return d
    }
    var c = this.t;
    d = c - b.t;
    if (d != 0) {
        return d
    }
    while (--c >= 0) {
        if ((d = this[c] - b[c]) != 0) {
            return d
        }
    }
    return 0
}

function nbits(b) {
    var d = 1,
        c;
    if ((c = b >>> 16) != 0) {
        b = c;
        d += 16
    }
    if ((c = b >> 8) != 0) {
        b = c;
        d += 8
    }
    if ((c = b >> 4) != 0) {
        b = c;
        d += 4
    }
    if ((c = b >> 2) != 0) {
        b = c;
        d += 2
    }
    if ((c = b >> 1) != 0) {
        b = c;
        d += 1
    }
    return d
}

function bnBitLength() {
    if (this.t <= 0) {
        return 0
    }
    return this.DB * (this.t - 1) + nbits(this[this.t - 1] ^ (this.s & this.DM))
}

function bnpDLShiftTo(d, c) {
    var b;
    for (b = this.t - 1; b >= 0;
        --b) {
        c[b + d] = this[b]
    }
    for (b = d - 1; b >= 0;
        --b) {
        c[b] = 0
    }
    c.t = this.t + d;
    c.s = this.s
}

function bnpDRShiftTo(d, c) {
    for (var b = d; b < this.t;
        ++b) {
        c[b - d] = this[b]
    }
    c.t = Math.max(this.t - d, 0);
    c.s = this.s
}

function bnpLShiftTo(k, f) {
    var d = k % this.DB;
    var b = this.DB - d;
    var h = (1 << b) - 1;
    var g = Math.floor(k / this.DB),
        j = (this.s << d) & this.DM,
        e;
    for (e = this.t - 1; e >= 0;
        --e) {
        f[e + g + 1] = (this[e] >> b) | j;
        j = (this[e] & h) << d
    }
    for (e = g - 1; e >= 0;
        --e) {
        f[e] = 0
    }
    f[g] = j;
    f.t = this.t + g + 1;
    f.s = this.s;
    f.clamp()
}

function bnpRShiftTo(h, e) {
    e.s = this.s;
    var f = Math.floor(h / this.DB);
    if (f >= this.t) {
        e.t = 0;
        return
    }
    var c = h % this.DB;
    var b = this.DB - c;
    var g = (1 << c) - 1;
    e[0] = this[f] >> c;
    for (var d = f + 1; d < this.t;
        ++d) {
        e[d - f - 1] |= (this[d] & g) << b;
        e[d - f] = this[d] >> c
    }
    if (c > 0) {
        e[this.t - f - 1] |= (this.s & g) << b
    }
    e.t = this.t - f;
    e.clamp()
}

function bnpSubTo(d, f) {
    var e = 0,
        g = 0,
        b = Math.min(d.t, this.t);
    while (e < b) {
        g += this[e] - d[e];
        f[e++] = g & this.DM;
        g >>= this.DB
    }
    if (d.t < this.t) {
        g -= d.s;
        while (e < this.t) {
            g += this[e];
            f[e++] = g & this.DM;
            g >>= this.DB
        }
        g += this.s
    } else {
        g += this.s;
        while (e < d.t) {
            g -= d[e];
            f[e++] = g & this.DM;
            g >>= this.DB
        }
        g -= d.s
    }
    f.s = (g < 0) ? -1 : 0;
    if (g < -1) {
        f[e++] = this.DV + g
    } else {
        if (g > 0) {
            f[e++] = g
        }
    }
    f.t = e;
    f.clamp()
}

function bnpMultiplyTo(c, e) {
    var b = this.abs(),
        f = c.abs();
    var d = b.t;
    e.t = d + f.t;
    while (--d >= 0) {
        e[d] = 0
    }
    for (d = 0; d < f.t;
        ++d) {
        e[d + b.t] = b.am(0, f[d], e, d, 0, b.t)
    }
    e.s = 0;
    e.clamp();
    if (this.s != c.s) {
        BigInteger.ZERO.subTo(e, e)
    }
}

function bnpSquareTo(e) {
    var b = this.abs();
    var d = e.t = 2 * b.t;
    while (--d >= 0) {
        e[d] = 0
    }
    for (d = 0; d < b.t - 1;
        ++d) {
        var f = b.am(d, b[d], e, 2 * d, 0, 1);
        if ((e[d + b.t] += b.am(d + 1, 2 * b[d], e, 2 * d + 1, f, b.t - d - 1)) >= b.DV) {
            e[d + b.t] -= b.DV;
            e[d + b.t + 1] = 1
        }
    }
    if (e.t > 0) {
        e[e.t - 1] += b.am(d, b[d], e, 2 * d, 0, 1)
    }
    e.s = 0;
    e.clamp()
}

function bnpDivRemTo(o, k, h) {
    var x = o.abs();
    if (x.t <= 0) {
        return
    }
    var l = this.abs();
    if (l.t < x.t) {
        if (k != null) {
            k.fromInt(0)
        }
        if (h != null) {
            this.copyTo(h)
        }
        return
    }
    if (h == null) {
        h = nbi()
    }
    var f = nbi(),
        b = this.s,
        n = o.s;
    var w = this.DB - nbits(x[x.t - 1]);
    if (w > 0) {
        x.lShiftTo(w, f);
        l.lShiftTo(w, h)
    } else {
        x.copyTo(f);
        l.copyTo(h)
    }
    var s = f.t;
    var c = f[s - 1];
    if (c == 0) {
        return
    }
    var p = c * (1 << this.F1) + ((s > 1) ? f[s - 2] >> this.F2 : 0);
    var B = this.FV / p,
        A = (1 << this.F1) / p,
        z = 1 << this.F2;
    var v = h.t,
        u = v - s,
        g = (k == null) ? nbi() : k;
    f.dlShiftTo(u, g);
    if (h.compareTo(g) >= 0) {
        h[h.t++] = 1;
        h.subTo(g, h)
    }
    BigInteger.ONE.dlShiftTo(s, g);
    g.subTo(f, f);
    while (f.t < s) {
        f[f.t++] = 0
    }
    while (--u >= 0) {
        var d = (h[--v] == c) ? this.DM : Math.floor(h[v] * B + (h[v - 1] + z) * A);
        if ((h[v] += f.am(0, d, h, u, 0, s)) < d) {
            f.dlShiftTo(u, g);
            h.subTo(g, h);
            while (h[v] < --d) {
                h.subTo(g, h)
            }
        }
    }
    if (k != null) {
        h.drShiftTo(s, k);
        if (b != n) {
            BigInteger.ZERO.subTo(k, k)
        }
    }
    h.t = s;
    h.clamp();
    if (w > 0) {
        h.rShiftTo(w, h)
    }
    if (b < 0) {
        BigInteger.ZERO.subTo(h, h)
    }
}

function Classic(b) {
    this.m = b
}

function cConvert(b) {
    if (b.s < 0 || b.compareTo(this.m) >= 0) {
        return b.mod(this.m)
    } else {
        return b
    }
}

function cRevert(b) {
    return b
}

function cReduce(b) {
    b.divRemTo(this.m, null, b)
}

function cMulTo(b, d, c) {
    b.multiplyTo(d, c);
    this.reduce(c)
}

function cSqrTo(b, c) {
    b.squareTo(c);
    this.reduce(c)
}
Classic.prototype.convert = cConvert;
Classic.prototype.revert = cRevert;
Classic.prototype.reduce = cReduce;
Classic.prototype.mulTo = cMulTo;
Classic.prototype.sqrTo = cSqrTo;

function bnpInvDigit() {
    if (this.t < 1) {
        return 0
    }
    var b = this[0];
    if ((b & 1) == 0) {
        return 0
    }
    var c = b & 3;
    c = (c * (2 - (b & 15) * c)) & 15;
    c = (c * (2 - (b & 255) * c)) & 255;
    c = (c * (2 - (((b & 65535) * c) & 65535))) & 65535;
    c = (c * (2 - b * c % this.DV)) % this.DV;
    return (c > 0) ? this.DV - c : -c
}

function Montgomery(b) {
    this.m = b;
    this.mp = b.invDigit();
    this.mpl = this.mp & 32767;
    this.mph = this.mp >> 15;
    this.um = (1 << (b.DB - 15)) - 1;
    this.mt2 = 2 * b.t
}

function montConvert(b) {
    var c = nbi();
    b.abs().dlShiftTo(this.m.t, c);
    c.divRemTo(this.m, null, c);
    if (b.s < 0 && c.compareTo(BigInteger.ZERO) > 0) {
        this.m.subTo(c, c)
    }
    return c
}

function montRevert(b) {
    var c = nbi();
    b.copyTo(c);
    this.reduce(c);
    return c
}

function montReduce(b) {
    while (b.t <= this.mt2) {
        b[b.t++] = 0
    }
    for (var d = 0; d < this.m.t;
        ++d) {
        var c = b[d] & 32767;
        var e = (c * this.mpl + (((c * this.mph + (b[d] >> 15) * this.mpl) & this.um) << 15)) & b.DM;
        c = d + this.m.t;
        b[c] += this.m.am(0, e, b, d, 0, this.m.t);
        while (b[c] >= b.DV) {
            b[c] -= b.DV;
            b[++c]++
        }
    }
    b.clamp();
    b.drShiftTo(this.m.t, b);
    if (b.compareTo(this.m) >= 0) {
        b.subTo(this.m, b)
    }
}

function montSqrTo(b, c) {
    b.squareTo(c);
    this.reduce(c)
}

function montMulTo(b, d, c) {
    b.multiplyTo(d, c);
    this.reduce(c)
}
Montgomery.prototype.convert = montConvert;
Montgomery.prototype.revert = montRevert;
Montgomery.prototype.reduce = montReduce;
Montgomery.prototype.mulTo = montMulTo;
Montgomery.prototype.sqrTo = montSqrTo;

function bnpIsEven() {
    return ((this.t > 0) ? (this[0] & 1) : this.s) == 0
}

function bnpExp(j, k) {
    var h = nbi(),
        b = nbi(),
        f = k.convert(this),
        d = nbits(j) - 1;
    f.copyTo(h);
    while (--d >= 0) {
        k.sqrTo(h, b);
        if ((j & (1 << d)) > 0) {
            k.mulTo(b, f, h)
        } else {
            var c = h;
            h = b;
            b = c
        }
    }
    return k.revert(h)
}

function bnModPowInt(c, b) {
    var d;
    if (c < 256 || b.isEven()) {
        d = new Classic(b)
    } else {
        d = new Montgomery(b)
    }
    return this.exp(c, d)
}

function bnpBitwiseTo(c, h, e) {
    var d, g, b = Math.min(c.t, this.t);
    for (d = 0; d < b;
        ++d) {
        e[d] = h(this[d], c[d])
    }
    if (c.t < this.t) {
        g = c.s & this.DM;
        for (d = b; d < this.t;
            ++d) {
            e[d] = h(this[d], g)
        }
        e.t = this.t
    } else {
        g = this.s & this.DM;
        for (d = b; d < c.t;
            ++d) {
            e[d] = h(g, c[d])
        }
        e.t = c.t
    }
    e.s = h(this.s, c.s);
    e.clamp()
}

function op_xor(b, c) {
    return b ^ c
}

function bnXor(b) {
    var c = nbi();
    this.bitwiseTo(b, op_xor, c);
    return c
}

function lbit(b) {
    if (b == 0) {
        return -1
    }
    var c = 0;
    if ((b & 65535) == 0) {
        b >>= 16;
        c += 16
    }
    if ((b & 255) == 0) {
        b >>= 8;
        c += 8
    }
    if ((b & 15) == 0) {
        b >>= 4;
        c += 4
    }
    if ((b & 3) == 0) {
        b >>= 2;
        c += 2
    }
    if ((b & 1) == 0) {
        ++c
    }
    return c
}
BigInteger.prototype.copyTo = bnpCopyTo;
BigInteger.prototype.fromInt = bnpFromInt;
BigInteger.prototype.fromString = bnpFromString;
BigInteger.prototype.clamp = bnpClamp;
BigInteger.prototype.dlShiftTo = bnpDLShiftTo;
BigInteger.prototype.subTo = bnpSubTo;
BigInteger.prototype.rShiftTo = bnpRShiftTo;
BigInteger.prototype.drShiftTo = bnpDRShiftTo;
BigInteger.prototype.invDigit = bnpInvDigit;
BigInteger.prototype.isEven = bnpIsEven;
BigInteger.prototype.multiplyTo = bnpMultiplyTo;
BigInteger.prototype.lShiftTo = bnpLShiftTo;
BigInteger.prototype.divRemTo = bnpDivRemTo;
BigInteger.prototype.squareTo = bnpSquareTo;
BigInteger.prototype.exp = bnpExp;
BigInteger.prototype.bitwiseTo = bnpBitwiseTo;
BigInteger.prototype.toString = bnToString;
BigInteger.prototype.negate = bnNegate;
BigInteger.prototype.abs = bnAbs;
BigInteger.prototype.compareTo = bnCompareTo;
BigInteger.prototype.bitLength = bnBitLength;
BigInteger.prototype.modPowInt = bnModPowInt;
BigInteger.prototype.xor = bnXor;
BigInteger.ZERO = nbv(0);
BigInteger.ONE = nbv(1);
/*
 * @fileOverview Javascript MD5 implementation(md5.js)
 * @version 1.0
 */
/*
 *
 *  MD5 (Message-Digest Algorithm)
 *  http://www.webtoolkit.info/
 *
 **/
var MD5 = function(s) {
    function L(b, a) {
        return (b << a) | (b >>> (32 - a))
    }

    function K(k, b) {
        var F, a, d, x, c;
        d = (k & 2147483648);
        x = (b & 2147483648);
        F = (k & 1073741824);
        a = (b & 1073741824);
        c = (k & 1073741823) + (b & 1073741823);
        if (F & a) {
            return (c ^ 2147483648 ^ d ^ x)
        }
        if (F | a) {
            if (c & 1073741824) {
                return (c ^ 3221225472 ^ d ^ x)
            } else {
                return (c ^ 1073741824 ^ d ^ x)
            }
        } else {
            return (c ^ d ^ x)
        }
    }

    function r(a, c, b) {
        return (a & c) | ((~a) & b)
    }

    function q(a, c, b) {
        return (a & b) | (c & (~b))
    }

    function p(a, c, b) {
        return (a ^ c ^ b)
    }

    function n(a, c, b) {
        return (c ^ (a | (~b)))
    }

    function u(G, F, aa, Z, k, H, I) {
        G = K(G, K(K(r(F, aa, Z), k), I));
        return K(L(G, H), F)
    }

    function f(G, F, aa, Z, k, H, I) {
        G = K(G, K(K(q(F, aa, Z), k), I));
        return K(L(G, H), F)
    }

    function D(G, F, aa, Z, k, H, I) {
        G = K(G, K(K(p(F, aa, Z), k), I));
        return K(L(G, H), F)
    }

    function t(G, F, aa, Z, k, H, I) {
        G = K(G, K(K(n(F, aa, Z), k), I));
        return K(L(G, H), F)
    }

    function e(k) {
        var G;
        var d = k.length;
        var c = d + 8;
        var b = (c - (c % 64)) / 64;
        var F = (b + 1) * 16;
        var H = Array(F - 1);
        var a = 0;
        var x = 0;
        while (x < d) {
            G = (x - (x % 4)) / 4;
            a = (x % 4) * 8;
            H[G] = (H[G] | (k.charCodeAt(x) << a));
            x++
        }
        G = (x - (x % 4)) / 4;
        a = (x % 4) * 8;
        H[G] = H[G] | (128 << a);
        H[F - 2] = d << 3;
        H[F - 1] = d >>> 29;
        return H
    }

    function B(c) {
        var b = "",
            d = "",
            k, a;
        for (a = 0; a <= 3; a++) {
            k = (c >>> (a * 8)) & 255;
            d = "0" + k.toString(16);
            b = b + d.substr(d.length - 2, 2)
        }
        return b
    }

    function J(b) {
        b = b.replace(/\r\n/g, "\n");
        var a = "";
        for (var k = 0; k < b.length; k++) {
            var d = b.charCodeAt(k);
            if (d < 128) {
                a += String.fromCharCode(d)
            } else {
                if ((d > 127) && (d < 2048)) {
                    a += String.fromCharCode((d >> 6) | 192);
                    a += String.fromCharCode((d & 63) | 128)
                } else {
                    a += String.fromCharCode((d >> 12) | 224);
                    a += String.fromCharCode(((d >> 6) & 63) | 128);
                    a += String.fromCharCode((d & 63) | 128)
                }
            }
        }
        return a
    }
    var C = Array();
    var P, h, E, v, g, Y, X, W, V;
    var S = 7,
        Q = 12,
        N = 17,
        M = 22;
    var A = 5,
        z = 9,
        y = 14,
        w = 20;
    var o = 4,
        m = 11,
        l = 16,
        j = 23;
    var U = 6,
        T = 10,
        R = 15,
        O = 21;
    s = J(s);
    C = e(s);
    Y = 1732584193;
    X = 4023233417;
    W = 2562383102;
    V = 271733878;
    for (P = 0; P < C.length; P += 16) {
        h = Y;
        E = X;
        v = W;
        g = V;
        Y = u(Y, X, W, V, C[P + 0], S, 3614090360);
        V = u(V, Y, X, W, C[P + 1], Q, 3905402710);
        W = u(W, V, Y, X, C[P + 2], N, 606105819);
        X = u(X, W, V, Y, C[P + 3], M, 3250441966);
        Y = u(Y, X, W, V, C[P + 4], S, 4118548399);
        V = u(V, Y, X, W, C[P + 5], Q, 1200080426);
        W = u(W, V, Y, X, C[P + 6], N, 2821735955);
        X = u(X, W, V, Y, C[P + 7], M, 4249261313);
        Y = u(Y, X, W, V, C[P + 8], S, 1770035416);
        V = u(V, Y, X, W, C[P + 9], Q, 2336552879);
        W = u(W, V, Y, X, C[P + 10], N, 4294925233);
        X = u(X, W, V, Y, C[P + 11], M, 2304563134);
        Y = u(Y, X, W, V, C[P + 12], S, 1804603682);
        V = u(V, Y, X, W, C[P + 13], Q, 4254626195);
        W = u(W, V, Y, X, C[P + 14], N, 2792965006);
        X = u(X, W, V, Y, C[P + 15], M, 1236535329);
        Y = f(Y, X, W, V, C[P + 1], A, 4129170786);
        V = f(V, Y, X, W, C[P + 6], z, 3225465664);
        W = f(W, V, Y, X, C[P + 11], y, 643717713);
        X = f(X, W, V, Y, C[P + 0], w, 3921069994);
        Y = f(Y, X, W, V, C[P + 5], A, 3593408605);
        V = f(V, Y, X, W, C[P + 10], z, 38016083);
        W = f(W, V, Y, X, C[P + 15], y, 3634488961);
        X = f(X, W, V, Y, C[P + 4], w, 3889429448);
        Y = f(Y, X, W, V, C[P + 9], A, 568446438);
        V = f(V, Y, X, W, C[P + 14], z, 3275163606);
        W = f(W, V, Y, X, C[P + 3], y, 4107603335);
        X = f(X, W, V, Y, C[P + 8], w, 1163531501);
        Y = f(Y, X, W, V, C[P + 13], A, 2850285829);
        V = f(V, Y, X, W, C[P + 2], z, 4243563512);
        W = f(W, V, Y, X, C[P + 7], y, 1735328473);
        X = f(X, W, V, Y, C[P + 12], w, 2368359562);
        Y = D(Y, X, W, V, C[P + 5], o, 4294588738);
        V = D(V, Y, X, W, C[P + 8], m, 2272392833);
        W = D(W, V, Y, X, C[P + 11], l, 1839030562);
        X = D(X, W, V, Y, C[P + 14], j, 4259657740);
        Y = D(Y, X, W, V, C[P + 1], o, 2763975236);
        V = D(V, Y, X, W, C[P + 4], m, 1272893353);
        W = D(W, V, Y, X, C[P + 7], l, 4139469664);
        X = D(X, W, V, Y, C[P + 10], j, 3200236656);
        Y = D(Y, X, W, V, C[P + 13], o, 681279174);
        V = D(V, Y, X, W, C[P + 0], m, 3936430074);
        W = D(W, V, Y, X, C[P + 3], l, 3572445317);
        X = D(X, W, V, Y, C[P + 6], j, 76029189);
        Y = D(Y, X, W, V, C[P + 9], o, 3654602809);
        V = D(V, Y, X, W, C[P + 12], m, 3873151461);
        W = D(W, V, Y, X, C[P + 15], l, 530742520);
        X = D(X, W, V, Y, C[P + 2], j, 3299628645);
        Y = t(Y, X, W, V, C[P + 0], U, 4096336452);
        V = t(V, Y, X, W, C[P + 7], T, 1126891415);
        W = t(W, V, Y, X, C[P + 14], R, 2878612391);
        X = t(X, W, V, Y, C[P + 5], O, 4237533241);
        Y = t(Y, X, W, V, C[P + 12], U, 1700485571);
        V = t(V, Y, X, W, C[P + 3], T, 2399980690);
        W = t(W, V, Y, X, C[P + 10], R, 4293915773);
        X = t(X, W, V, Y, C[P + 1], O, 2240044497);
        Y = t(Y, X, W, V, C[P + 8], U, 1873313359);
        V = t(V, Y, X, W, C[P + 15], T, 4264355552);
        W = t(W, V, Y, X, C[P + 6], R, 2734768916);
        X = t(X, W, V, Y, C[P + 13], O, 1309151649);
        Y = t(Y, X, W, V, C[P + 4], U, 4149444226);
        V = t(V, Y, X, W, C[P + 11], T, 3174756917);
        W = t(W, V, Y, X, C[P + 2], R, 718787259);
        X = t(X, W, V, Y, C[P + 9], O, 3951481745);
        Y = K(Y, h);
        X = K(X, E);
        W = K(W, v);
        V = K(V, g)
    }
    var i = B(Y) + B(X) + B(W) + B(V);
    return i.toLowerCase()
};
/*
 * @fileOverview Javascript RSA implementation(rsa.js)
 * @version 1.6
 */
/*
 * This package includes code written by Tom Wu.
 *
 * Copyright (c) 2003-2005  Tom Wu
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 */
/*
 * Copyright (c) 2003-2005  Tom Wu
 * http://www-cs-students.stanford.edu/~tjw/jsbn/
 * All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT SHALL TOM WU BE LIABLE FOR ANY SPECIAL, INCIDENTAL,
 * INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND, OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER OR NOT ADVISED OF
 * THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF LIABILITY, ARISING OUT
 * OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * In addition, the following condition applies:
 *
 * All redistributions must retain an intact copy of this copyright notice
 * and disclaimer.
 */
function parseBigInt(b, a) {
    return new BigInteger(b, a)
}

function pkcs1pad2B(c, h) {
    var g = c.length;
    if (g > h - 11 - 4) {
        throw "104"
    }
    var a = [0, 2, 255, 255, 255, 255];
    var b = h - g - 3 - 4;
    var f = randomBytes(b);
    var d = a.concat(f, [0], c);
    var e = new BigInteger(d);
    return e
}

function randomBytes(c) {
    var a = [];
    var b = 0;
    for (b = 0; b < c; b++) {
        a[b] = Math.ceil(Math.random() * 255)
    }
    return a
}

function pkcs1pad2(f, a) {
    var j = Math.ceil(f.bitLength() / 8);
    if (a < j + 11) {
        alert("Message too long for RSA");
        return null
    }
    var e = [0, 2];
    var b;
    b = a - j - 3;
    var d = 2;
    while (d < b + 2) {
        var g = 0;
        while (g == 0) {
            g = Math.floor(Math.random() * 255)
        }
        e[d++] = g
    }
    var h = new BigInteger(e);
    var c = h.toString(16) + "00" + f.toString(16);
    return new BigInteger(c, 16)
}

function pkcs1pad2S(f, a) {
    var j = Math.ceil(f.bitLength() / 8);
    if (a < j + 11) {
        alert("Message too long for RSA");
        return null
    }
    var e = [0, 2];
    var b;
    b = a - j - 3;
    var d = 2;
    while (d < b + 2) {
        var g = 0;
        while (g == 0) {
            g = Math.floor(Math.random() * 255)
        }
        e[d++] = g
    }
    var h = new BigInteger(e);
    var c = h.toString(16) + "00" + f.toString(16);
    return new BigInteger(c, 16)
}

function RSAKey() {
    this.n = null;
    this.e = 0;
    this.d = null
}
RSAKey.prototype.setPublic = function(b, a) {
    if (b != null && a != null && b.length > 0 && a.length > 0) {
        this.n = parseBigInt(b, 16);
        this.e = parseInt(a, 16)
    } else {
        alert("Invalid RSA public key")
    }
};
RSAKey.prototype.doPublic = function(a) {
    return a.modPowInt(this.e, this.n)
};
RSAKey.prototype.encryptNativeHexStr = function(e) {
    var j = e.length / 2;
    var g = (this.n.bitLength() + 7) >> 3;
    if (j > g) {
        throw "104"
    }
    var a = new BigInteger(e, 16);
    var f = this.doPublic(a);
    if (f == null) {
        return null
    }
    var d = f.toString(16);
    if (d.length > 256) {
        return null
    }
    if (d.length < 256) {
        for (var b = 0; b < (256 - d.length); b++) {
            d = "0" + d
        }
    }
    return d
};
RSAKey.prototype.encryptNativeBytes = function(b) {
    var j = b.length;
    var g = (this.n.bitLength() + 7) >> 3;
    if (j > g) {
        throw "104"
    }
    var a = new BigInteger(b);
    var f = this.doPublic(a);
    if (f == null) {
        return null
    }
    var e = f.toString(16);
    if (e.length > 256) {
        return null
    }
    var constantLength = e.length;
    if (e.length < 256) {
        for (var d = 0; d < (256 - constantLength); d++) {
            e = "0" + e;
        }
    }
    return e
};
RSAKey.prototype.encryptS = function(d) {
    var a = pkcs1pad2S(d, (this.n.bitLength() + 7) >> 3);
    if (a == null) {
        return null
    }
    var f = this.doPublic(a);
    if (f == null) {
        return null
    }
    var e = f.toString(16);
    if (e.length > 256) {
        return null
    }
    if (e.length < 256) {
        for (var b = 0; b < (256 - e.length); b++) {
            e = "0" + e
        }
    }
    return e
};
RSAKey.prototype.encrypt = function(b) {
    var f = (this.n.bitLength() + 7) >> 3;
    var a = pkcs1pad2(b, f);
    if (a == null) {
        return null
    }
    var i = this.doPublic(a);
    if (i == null) {
        return null
    }
    var e = i.toString(16);
    if (e.length > f * 2) {
        return null
    }
    var g = "";
    if (e.length < f * 2) {
        for (var d = 0; d < (f * 2 - e.length); d++) {
            g = g.concat("0")
        }
    }
    return g.concat(e)
};
RSAKey.prototype.encryptB = function(b) {
    var a = pkcs1pad2B(b, (this.n.bitLength() + 7) >> 3);
    if (a == null) {
        return null
    }
    var g = this.doPublic(a);
    if (g == null) {
        return null
    }
    var e = g.toString(16);
    if (e.length > 256) {
        return null
    }
    var f = "";
    if (e.length < 256) {
        for (var d = 0; d < (256 - e.length); d++) {
            f = f.concat("0")
        }
    }
    return f.concat(e)
};

/*
 * JavaScript implementation to include SHA1 capability on passwords before encryption
 * @author Yuan Kwang
 * @company DS3, http://www.ds3global.com
 * @version 1.0
 *
 */
var Is2048 = false;


function EncryptData(rsaPublicKey, data, random) {
    if (rsaPublicKey == null || rsaPublicKey.length == 0) {
        throw "RSA Public Key is empty!";
        return;
    }
    if (data == null || data.length == 0) {
        throw "Data is empty!";
        return;
    }
    if (random == null || random.length == 0) {
        throw "Random is empty!";
        return;
    }
    var rawRandom = random.substring(0, 16);
    if (rsaPublicKey.length == 512) {
        Is2048 = true;
    }
    var A = buildPKCS15BlockForPinVerify(data, rawRandom);
    var B = new RSAKey();
    B.setPublic(rsaPublicKey, "10001");
    var C = B.encryptNativeBytes(A);
    return C;
};


/**
 * This method builds a byte array that is in accordance with PKCS#1 v1.5
 * standard according to section 10.1 of Group Internet Banking System (GIB)
 * Communication Message Specification for PIN verify operation
 *
 * @param password
 *            The users password
 * @param random
 *            The random number as supplied from the Authentication Server
 * @return a 128 byte array corresponding to the PKCS block
 * @throws UnsupportedEncodingException
 *             if ISO-8859-1 encoding is not supported
 */
function buildPKCS15BlockForPinVerify(password, random) {
    if (password.length > 100) {
        alert("Data must be less than 100 bytes");
        return;
    }
    var bytes = new Array();
    var pwdBytes = getByteArray(password);
    var passwordBlock = new Array(109);
    for (var i = 0; i < 109; i++) {
        if (i < pwdBytes.length)
            passwordBlock[i] = pwdBytes[i];
        else
            passwordBlock[i] = 0xFF;
    }
    var randomBytes = fromHexString(random);
    var maxSize = 128;
    if (Is2048 == true) {
        maxSize = 256
    }
    var padLength = maxSize - randomBytes.length - passwordBlock.length;
    var bytesPad = getRandomBytes(padLength);
    for (var i = 0; i < padLength; i++) {
        if (bytesPad[i] == 0x00) {
            bytesPad[i] = 0x27;
        }
    }
    bytesPad[0] = 0x00;
    bytesPad[1] = 0x02;
    bytesPad[10] = 0x00;
    bytes = bytesPad.concat(randomBytes);
    bytes = bytes.concat(passwordBlock);
    return bytes;
}

/**
 * This builds a byte array that is in accordance with PKCS#1 v1.5 standard
 * according to section 10.1 of Group Internet Banking System (GIB)
 * Communication Message Specification for a PIN Change operation
 *
 * @param oldPassword
 * @param newPassword
 * @param random
 * @return
 * @throws UnsupportedEncodingException
 */
function buildPKCS15BlockForPinChange(oldPassword, newPassword, random) {
    /*
     * if(random.length!=16){alert("
     * random
     * number
     * must
     * be 8
     * bytes");return;}
     */
    if (oldPassword.length > 30) {
        alert("Existing Pin length must be less than 30 bytes");
        return;
    }
    if (newPassword.length > 30) {
        alert("New Pin length must be less than 30 bytes");
        return;
    }
    var bytes = new Array();
    var oldPINBytes = Util.getByteArray(oldPassword);
    var oldPasswordBytes = new Array(30);
    for (var i = 0; i < 30; i++) {
        if (i < oldPINBytes.length)
            oldPasswordBytes[i] = oldPINBytes[i];
        else
            oldPasswordBytes[i] = 0xFF;
    }
    var newPINBytes = Util.getByteArray(newPassword);
    var newPasswordBytes = new Array(30);
    for (var i = 0; i < 30; i++) {
        if (i < newPINBytes.length)
            newPasswordBytes[i] = newPINBytes[i];
        else
            newPasswordBytes[i] = 0xFF;
    }
    var randomBytes = Util.fromHexString(random);
    var maxSize = 128;
    if (Is2048 == true) {
        maxSize = 256
    }
    var padLength = maxSize - randomBytes.length - newPasswordBytes.length - oldPasswordBytes.length;
    var bytesPad = Util.randomBytes(padLength);
    for (var i = 0; i < padLength; i++) {
        if (bytesPad[i] == 0x00) {
            bytesPad[i] = 0x28;
        }
    }
    bytesPad[0] = 0x00;
    bytesPad[1] = 0x02;
    bytesPad[10] = 0x00;
    bytes = bytesPad.concat(randomBytes);
    bytes = bytes.concat(newPasswordBytes);
    bytes = bytes.concat(oldPasswordBytes);
    return bytes;
}



function getByteArray(B) {
    a = new Array();
    for (var A = 0; A < B.length; A++) {
        a[A] = B.charCodeAt(A)
    }
    return a
}

function fromHexString(D) {
    D = (D.length % 2 == 0) ? D : "0" + D;
    var A = D.length / 2;
    var E = [];
    for (var C = 0, B = 0; C < A; C++, B++) {
        var F = C * 2;
        E[B] = parseInt("0x" + D.substring(F, F + 2))
    }
    return E
}

function getRandomBytes(C) {
    var A = [];
    var B = 0;
    for (B = 0; B < C; B++) {
        A[B] = Math.ceil(Math.random() * 255)
    }
    return A
}

function pkcs1pad2(F, A) {
    var I = Math.ceil(F.bitLength() / 8);
    if (A < I + 11 + 4) {
        alert("Message too long for RSA");
        return null
    }
    var E = [0, 2, 255, 255, 255, 255];
    var B;
    B = A - I - 7;
    var G = 0;
    var D = 6;
    while (D < B + 6) {
        G = 0;
        while (G == 0) {
            G = Math.floor(Math.random() * 255)
        }
        E[D++] = G
    }
    var H = new BigInteger(E);
    var C = H.toString(16) + "00" + F.toString(16);
    return new BigInteger(C, 16)
}

function pkcs1pad2S(F, A) {
    var I = Math.ceil(F.bitLength() / 8);
    if (A < I + 11) {
        alert("Message too long for RSA");
        return null
    }
    var E = [0, 2];
    var B;
    B = A - I - 3;
    var D = 2;
    while (D < B + 2) {
        var G = 0;
        while (G == 0) {
            G = Math.floor(Math.random() * 255)
        }
        E[D++] = G
    }
    var H = new BigInteger(E);
    var C = H.toString(16) + "00" + F.toString(16);
    return new BigInteger(C, 16)
}


function RSAKey() {
    this.n = null;
    this.e = 0;
    this.d = null
}

RSAKey.prototype.setPublic = function(b, a) {
    if (b != null && a != null && b.length > 0 && a.length > 0) {
        this.n = parseBigInt(b, 16);
        this.e = parseInt(a, 16)
    } else {
        alert("Invalid RSA public key")
    }
};
RSAKey.prototype.doPublic = function(a) {
    return a.modPowInt(this.e, this.n)
};


RSAKey.prototype.encryptNativeHexStr = function(D) {
    var G = D.length / 2;
    var F = (this.n.bitLength() + 7) >> 3;
    if (G > F) {
        throw "104"
    }
    var A = new BigInteger(D, 16);
    var E = this.doPublic(A);
    if (E == null) {
        return null
    }
    var C = E.toString(16);
    if (C.length > 512) {
        return null
    }
    if (C.length < 512) {
        for (var B = 0; B < (512 - C.length); B++) {
            C = "0" + C
        }
    }
    return C
};

RSAKey.prototype.encryptNativeBytes = function(B) {

    var G = B.length;
    var F = (this.n.bitLength() + 7) >> 3;
    if (G > F) {
        throw "104"
    }
    var A = new BigInteger(B);
    var E = this.doPublic(A);
    if (E == null) {
        return null
    }
    var D = E.toString(16);
    var maxSize = 256;
    if (Is2048 == true) {
        maxSize = 512
    }
    if (D.length > maxSize) {
        return null
    }

    if (D.length < maxSize) {
        for (var C = 0; C < (maxSize - D.length); C++) {
            D = "0" + D

        }
    }
    return D
};

RSAKey.prototype.encryptS = function(C) {
    var A = pkcs1pad2S(C, (this.n.bitLength() + 7) >> 3);
    if (A == null) {
        return null
    }
    var E = this.doPublic(A);
    if (E == null) {
        return null
    }
    var D = E.toString(16);
    if (D.length > 512) {
        return null
    }
    if (D.length < 512) {
        for (var B = 0; B < (512 - D.length); B++) {
            D = "0" + D
        }
    }
    return D
};

RSAKey.prototype.encrypt = function(C) {
    var A = pkcs1pad2(C, (this.n.bitLength() + 7) >> 3);
    if (A == null) {
        return null
    }
    var E = this.doPublic(A);
    if (E == null) {
        return null
    }
    var D = E.toString(16);
    if (D.length > 512) {
        return null
    }
    var maxSize = 256;
    if (Is2048 == true) {
        maxSize = 512
    }
    if (D.lengthmaxSize) {
        for (var B = 0; B < (maxSize - D.length); B++) {
            D = "0" + D
        }
    }
    return D
};
RSAKey.prototype.encryptB = function(B) {
    var A = pkcs1pad2B(B, (this.n.bitLength() + 7) >> 3);
    if (A == null) {
        return null
    }
    var E = this.doPublic(A);
    if (E == null) {
        return null
    }
    var D = E.toString(16);
    if (D.length > maxSize) {
        return null
    }
    if (D.length < maxSize) {
        for (var C = 0; C < (maxSize - D.length); C++) {
            D = "0" + D
        }
    }
    return D
};

/*
 * @fileOverview DS3 End-end encryption toolkit<br>DSSS,
 * http://www.ds3global.com @author Pedric Kng
 *
 * @version 1.0
 */
function Util() {}
Util.parseBigInt = function(B, A) {
    return new BigInteger(B, A)
};
Util.randomString = function(C) {
    var A = "";
    var B = 0;
    for (B = 0; B < C; B++) {
        A = A + String.fromCharCode(Math.ceil(Math.random() * 255))
    }
    return A
};
Util.randomBytes = function(C) {
    var A = [];
    var B = 0;
    for (B = 0; B < C; B++) {
        A[B] = Math.ceil(Math.random() * 255)
    }
    return A
};
Util.toHexString = function(D) {
    var C = "";
    for (var A = 0; A < D.length; A++) {
        var B;
        if (typeof D[A] == "number") {
            B = (D[A]).toString(16)
        } else {
            if (typeof D[A] == "string") {
                B = D.charCodeAt(A).toString(16)
            }
        }
        if (B.length == 1) {
            B = "0" + B
        }
        C += B
    }
    return C
};
Util.fromHexString = function(D) {
    D = (D.length % 2 == 0) ? D : "0" + D;
    var A = D.length / 2;
    var E = [];
    for (var C = 0, B = 0; C < A; C++, B++) {
        var F = C * 2;
        E[B] = parseInt("0x" + D.substring(F, F + 2))
    }
    return E
};
Util.fromHexToString = function(C) {
    C = (C.length % 2 == 0) ? C : "0" + C;
    var A = C.length / 2;
    var D = "";
    for (var B = 0; B < A; B++) {
        var E = B * 2;
        D = D + String.fromCharCode(parseInt("0x" + C.substring(E, E + 2)))
    }
    return D
};
Util.cByteArrayToNString = function(C) {
    var A = "";
    for (var B = 0; B < C.length; B++) {
        A += String.fromCharCode(C[B])
    }
    return A
};
Util.getByteArray = function(B) {
    a = new Array();
    for (var A = 0; A < B.length; A++) {
        a[A] = B.charCodeAt(A)
    }
    return a
};
Util.xorByteArray = function(C, B) {
    if (C.length > B.length) {
        throw "Invalid parameters."
    }
    var A = [];
    for (var D = 0; D < C.length; D++) {
        A[D] = C[D] ^ B[D]
    }
    return A
};
Util.stringToHex = function(C) {
    var D = "";
    var B = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a",
        "b", "c", "d", "e", "f");
    for (var A = 0; A < C.length; A++) {
        D += B[C.charCodeAt(A) >> 4] + B[C.charCodeAt(A) & 15]
    }
    return D
};

/*
 * This package includes code written by Chris Veness.
 *
 * Copyright (c) 2005-2009 Chris Veness
 * http://www.movable-type.co.uk/scripts/sha1.html
 *
 */
function SHA1Hash(C) {
    var F = [1518500249, 1859775393, 2400959708, 3395469782];
    C += String.fromCharCode(128);
    var Q = C.length / 4 + 2;
    var D = Math.ceil(Q / 16);
    var E = new Array(D);
    for (var S = 0; S < D; S++) {
        E[S] = new Array(16);
        for (var R = 0; R < 16; R++) {
            E[S][R] = (C.charCodeAt(S * 64 + R * 4) << 24) | (C.charCodeAt(S * 64 + R * 4 + 1) << 16) | (C.charCodeAt(S * 64 + R * 4 + 2) << 8) | (C.charCodeAt(S * 64 + R * 4 + 3))
        }
    }
    E[D - 1][14] = ((C.length - 1) * 8) / Math.pow(2, 32);
    E[D - 1][14] = Math.floor(E[D - 1][14]);
    E[D - 1][15] = ((C.length - 1) * 8) & 4294967295;
    var L = 1732584193;
    var J = 4023233417;
    var I = 2562383102;
    var H = 271733878;
    var G = 3285377520;
    var A = new Array(80);
    var h, g, Z, X, V;
    for (var S = 0; S < D; S++) {
        for (var O = 0; O < 16; O++) {
            A[O] = E[S][O]
        }
        for (var O = 16; O < 80; O++) {
            A[O] = Y(A[O - 3] ^ A[O - 8] ^ A[O - 14] ^ A[O - 16], 1)
        }
        h = L;
        g = J;
        Z = I;
        X = H;
        V = G;
        for (var O = 0; O < 80; O++) {
            var P = Math.floor(O / 20);
            var B = (Y(h, 5) + U(P, g, Z, X) + V + F[P] + A[O]) & 4294967295;
            V = X;
            X = Z;
            Z = Y(g, 30);
            g = h;
            h = B
        }
        L = (L + h) & 4294967295;
        J = (J + g) & 4294967295;
        I = (I + Z) & 4294967295;
        H = (H + X) & 4294967295;
        G = (G + V) & 4294967295
    }
    return L.toHexStr() + J.toHexStr() + I.toHexStr() + H.toHexStr() + G.toHexStr();

    function U(M, K, T, N) {
        switch (M) {
            case 0:
                return (K & T) ^ (~K & N);
            case 1:
                return K ^ T ^ N;
            case 2:
                return (K & T) ^ (K & N) ^ (T & N);
            case 3:
                return K ^ T ^ N
        }
    }

    function Y(K, M) {
        return (K << M) | (K >>> (32 - M))
    }
}
Number.prototype.toHexStr = function() {
    var C = "",
        A;
    for (var B = 7; B >= 0; B--) {
        A = (this >>> (B * 4)) & 15;
        C += A.toString(16)
    }
    return C
};
/*
 * This package includes code written by Chris Veness.
 *
 * Copyright (c) 2005-2009 Chris Veness
 * http://www.movable-type.co.uk/scripts/sha256.html
 *
 */
function sha256Hash(B) {
    var E = [1116352408, 1899447441, 3049323471, 3921009573, 961987163,
        1508970993, 2453635748, 2870763221, 3624381080, 310598401,
        607225278, 1426881987, 1925078388, 2162078206, 2614888103,
        3248222580, 3835390401, 4022224774, 264347078, 604807628,
        770255983, 1249150122, 1555081692, 1996064986, 2554220882,
        2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
        113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
        1695183700, 1986661051, 2177026350, 2456956037, 2730485921,
        2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
        4094571909, 275423344, 430227734, 506948616, 659060556, 883997877,
        958139571, 1322822218, 1537002063, 1747873779, 1955562222,
        2024104815, 2227730452, 2361852424, 2428436474, 2756734187,
        3204031479, 3329325298
    ];
    var F = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119,
        2600822924, 528734635, 1541459225
    ];
    B += String.fromCharCode(128);
    var L = B.length / 4 + 2;
    var C = Math.ceil(L / 16);
    var D = new Array(C);
    for (var P = 0; P < C; P++) {
        D[P] = new Array(16);
        for (var O = 0; O < 16; O++) {
            D[P][O] = (B.charCodeAt(P * 64 + O * 4) << 24) | (B.charCodeAt(P * 64 + O * 4 + 1) << 16) | (B.charCodeAt(P * 64 + O * 4 + 2) << 8) | (B.charCodeAt(P * 64 + O * 4 + 3))
        }
    }
    D[C - 1][14] = ((B.length - 1) * 8) / Math.pow(2, 32);
    D[C - 1][14] = Math.floor(D[C - 1][14]);
    D[C - 1][15] = ((B.length - 1) * 8) & 4294967295;
    var A = new Array(64);
    var Y, X, V, U, T, S, R, Q;
    for (var P = 0; P < C; P++) {
        for (var I = 0; I < 16; I++) {
            A[I] = D[P][I]
        }
        for (var I = 16; I < 64; I++) {
            A[I] = (sigma1(A[I - 2]) + A[I - 7] + sigma0(A[I - 15]) + A[I - 16]) & 4294967295
        }
        Y = F[0];
        X = F[1];
        V = F[2];
        U = F[3];
        T = F[4];
        S = F[5];
        R = F[6];
        Q = F[7];
        for (var I = 0; I < 64; I++) {
            var J = Q + Sigma1(T) + Ch(T, S, R) + E[I] + A[I];
            var G = Sigma0(Y) + Maj(Y, X, V);
            Q = R;
            R = S;
            S = T;
            T = (U + J) & 4294967295;
            U = V;
            V = X;
            X = Y;
            Y = (J + G) & 4294967295
        }
        F[0] = (F[0] + Y) & 4294967295;
        F[1] = (F[1] + X) & 4294967295;
        F[2] = (F[2] + V) & 4294967295;
        F[3] = (F[3] + U) & 4294967295;
        F[4] = (F[4] + T) & 4294967295;
        F[5] = (F[5] + S) & 4294967295;
        F[6] = (F[6] + R) & 4294967295;
        F[7] = (F[7] + Q) & 4294967295
    }
    return F[0].toHexStr() + F[1].toHexStr() + F[2].toHexStr() + F[3].toHexStr() + F[4].toHexStr() + F[5].toHexStr() + F[6].toHexStr() + F[7].toHexStr()
}

function ROTR(B, A) {
    return (A >>> B) | (A << (32 - B))
}

function Sigma0(A) {
    return ROTR(2, A) ^ ROTR(13, A) ^ ROTR(22, A)
}

function Sigma1(A) {
    return ROTR(6, A) ^ ROTR(11, A) ^ ROTR(25, A)
}

function sigma0(A) {
    return ROTR(7, A) ^ ROTR(18, A) ^ (A >>> 3)
}

function sigma1(A) {
    return ROTR(17, A) ^ ROTR(19, A) ^ (A >>> 10)
}

function Ch(A, C, B) {
    return (A & C) ^ (~A & B)
}

function Maj(A, C, B) {
    return (A & C) ^ (A & B) ^ (C & B)
}
Number.prototype.toHexStr = function() {
    var C = "",
        A;
    for (var B = 7; B >= 0; B--) {
        A = (this >>> (B * 4)) & 15;
        C += A.toString(16)
    }
    return C
};